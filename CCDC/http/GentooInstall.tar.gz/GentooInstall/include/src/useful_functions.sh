#!/bin/bash
# Author  : Bailey Kasin
# Date    : 1/9/2018
# Purpose : Useful functions to add ease of use

function redEcho
{
    echo -e $1
}

function greenEcho
{
    echo -e $1
}

function orangeEcho
{
    echo -e $1
}

function blueEcho
{
    echo -e $1
}

function pinkEcho
{
    echo -e $1
}